# CustomizableRPG
This is a mod that allows you to have a fully customizable RPG world in WorldBox.
